﻿namespace lab12.Models
{
    public class FormData
    {
        public int firstValue { get; set; }
        public int secondValue { get; set; }
        public string operation { get; set; }
    }
}
